package es.uib.owu.liferay.portlet;

import com.liferay.util.bridges.mvc.MVCPortlet;

public class ServiceBuilderPortlet extends MVCPortlet{

}
